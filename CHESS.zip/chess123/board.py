import chess
import chess.svg
from IPython.display import SVG
SVG(chess.svg.piece(chess.Piece.from_symbol("R")))
